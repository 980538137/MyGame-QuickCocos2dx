
display.addSpriteFramesWithFile = DEPRECATED(display.addSpriteFrames, "display.addSpriteFramesWithFile", "display.addSpriteFrames")
