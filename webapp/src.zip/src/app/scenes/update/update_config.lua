

SCRIPT_VERSION = "1.0.0" 	--脚本版本号
APP_VERSION = "1"			--app版本号，如果低就整包更新

CONFIG_UPDATE_URL = "http://192.168.0.1:8080/check_update"